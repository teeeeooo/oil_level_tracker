"""Compare one shadow scorer on pinned saved raw candidates, with fresh resolver."""
import sys, json, copy, hashlib, os
from pathlib import Path
from dataclasses import asdict
from enum import Enum
ROOT=Path(os.environ.get('OIL_REPO','/Users/sunjaekim/Developer/oil_level_tracker'))
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'src'),str(ROOT/'tests')]
import cv2
from paired_challenger import rescore, COUNTS
from oil_tracker.adapters.storage.json_recipe_repository import JsonRecipeRepository
from oil_tracker.adapters.vision.opencv_phase_detector import OpenCvPhaseDetector
from oil_tracker.adapters.vision.geometry_masks import build_mask_bundle
from oil_tracker.adapters.vision.preprocessing import preprocess
from oil_tracker.domain.detection import PhaseDetection,BoundaryCandidate
from oil_tracker.domain.enums import FillState,BoundaryKind

def encode(x):
    if isinstance(x,Enum):return x.value
    raise TypeError(type(x).__name__)

def convert(d):
    d=copy.deepcopy(d);d['fill_state']=FillState(d['fill_state'])
    d['candidates']=[BoundaryCandidate(**dict(c,kind=BoundaryKind(c['kind']))) for c in d['candidates']]
    return PhaseDetection(**d)

source=ROOT/'sample/output/s11-local-human-roi-sequence-001/human_roi.json'
recipe=ROOT/'sample/output/s11-local-human-roi-comparison-001/sample4-human-roi.oilrecipe'
video=ROOT/'sample/sample4.mp4'
pins={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [source,recipe,video]}
glass=JsonRecipeRepository().load(recipe).glasses[0]
raw=[convert(r['raw']) for r in json.loads(source.read_text(encoding='utf-8'))['rows']]
base=OpenCvPhaseDetector().resolve_sequence(copy.deepcopy(raw),glass,confirmed_initial_state=None)
changed=copy.deepcopy(raw);cap=cv2.VideoCapture(str(video),cv2.CAP_FFMPEG)
for detection in changed:
    cap.set(cv2.CAP_PROP_POS_FRAMES,detection.frame_index);ok,frame=cap.read();assert ok
    assert cap.get(cv2.CAP_PROP_POS_FRAMES)==detection.frame_index+1
    bundle=build_mask_bundle(frame,glass);pre=preprocess(bundle.crop,bundle.effective_mask,glass.detector_settings)
    original=[(c.kind,c.source,c.y) for c in detection.candidates]
    detection.candidates=[rescore(c,pre,bundle.effective_mask,bundle.crop_origin[1])
        if c.source=='phase_transition_scan' else c for c in detection.candidates]
    assert original==[(c.kind,c.source,c.y) for c in detection.candidates]
cap.release()
challenger=OpenCvPhaseDetector().resolve_sequence(changed,glass,confirmed_initial_state=None)
results={}
for name,result in [('baseline',base),('challenger',challenger)]:
    rows=[]
    for d in result.detections:
        selected=[c for c in d.candidates if c.kind is BoundaryKind.OIL_AIR and c.selected]
        if d.raw_oil_air_level_y is not None:
            assert len(selected)==1 and selected[0].y==d.raw_oil_air_level_y
        rows.append({'frame':d.frame_index,'oil':d.raw_oil_air_level_y,'foam':d.raw_foam_front_y,
            'state':d.fill_state.value,'sources':[c.source for c in selected]})
    results[name]={'oil_count':sum(r['oil'] is not None for r in rows),
                   'foam_count':sum(r['foam'] is not None for r in rows),'rows':rows}
for path,digest in pins.items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
report={'schema':'s11-paired-sequence-experiment-v1','inputs':pins,'counts':COUNTS,'results':results,
        'limits':'Saved exposed 30fps human-ROI diagnostic, fixed original candidate identities. No independent physical labels or efficacy acceptance.'}
(OUT/'paired_sequence.json').write_text(json.dumps(report,indent=2,default=encode,allow_nan=False)+'\n',encoding='utf-8')
print(json.dumps({k:{'oil':v['oil_count'],'foam':v['foam_count'],
    'checkpoints':[r for r in v['rows'] if r['frame'] in [420,450,480]]} for k,v in results.items()}),flush=True)
