"""One preregistered process-only challenger; NEVER installed in production."""
from __future__ import annotations
from dataclasses import replace
import numpy as np
from paired_support import measure, RADII

COUNTS = {'candidates': 0, 'available': 0, 'unavailable': 0}

def rescore(candidate, pre, effective_mask, crop_origin_y):
    local = int(round(candidate.y-crop_origin_y))
    visible = (effective_mask>0)&(pre.glare_mask==0)
    view = measure(pre.normalized, visible, local)
    scales=[]
    for radius in RADII:
        eligible=[r for r in view['measurements'] if r['radius']==radius
            and len(r['paired_columns'])*radius >= max(2,int(radius*max(1,r['last_x']-r['first_x'])*.25))]
        if len(eligible)<3:
            scales.append((0.0,0.0,0.0,False));continue
        delta=np.array([r['paired_mean_delta']/48 for r in eligible])
        scales.append((min(1.0,float(np.median(np.abs(delta)))),len(eligible)/5,
                       float(np.median(delta)),True))
    COUNTS['candidates']+=1
    if not any(r[3] for r in scales):
        COUNTS['unavailable']+=1
        return replace(candidate,features={**candidate.features,'sequence_eligible':0.0,
            'evidence_availability':0.0,'visibility':0.0,'audit_paired_available':0.0})
    COUNTS['available']+=1
    best=max(range(3),key=lambda i:scales[i][0])
    strength,coverage,signed,_=scales[best]
    consistency=sum(r[3] and r[0]>=max(.08,strength*.60) for r in scales)/3
    availability=float(candidate.features['evidence_availability'])
    artifact=float(candidate.features['artifact_likelihood'])
    boundary=min(1.0,max(0.0,.42*strength+.24*coverage+.18*consistency+.16*availability))
    ambiguity=min(1.0,max(0.0,.40*(1-strength)+.24*(1-coverage)+.20*(1-consistency)+.16*artifact))
    features={**candidate.features,'boundary_likelihood':boundary,'ambiguity_likelihood':ambiguity,
        'broad_strength':strength,'narrow_peak_strength':strength,'narrow_horizontal_coverage':coverage,
        'broad_scale_consistency':consistency,'polarity_confidence':min(1.0,abs(signed)),
        'audit_paired_available':1.0}
    return replace(candidate,features=features,
        penalties={**candidate.penalties,'ambiguity_likelihood':ambiguity},
        feature_score=boundary,penalty=min(1.0,artifact+ambiguity),final_score=boundary)


def install():
    import oil_tracker.adapters.vision.phase_candidate_assembler as assembler
    original=assembler.generate_phase_transition_candidates
    def wrapped(pre,effective_mask,static_artifact_map,*,crop_origin_y,limit=4):
        original_candidates=original(pre,effective_mask,static_artifact_map,
                                     crop_origin_y=crop_origin_y,limit=limit)
        updated=tuple(rescore(c,pre,effective_mask,crop_origin_y) for c in original_candidates)
        assert [(c.y,c.source) for c in updated]==[(c.y,c.source) for c in original_candidates]
        return updated
    assembler.generate_phase_transition_candidates=wrapped
    return lambda:setattr(assembler,'generate_phase_transition_candidates',original)
