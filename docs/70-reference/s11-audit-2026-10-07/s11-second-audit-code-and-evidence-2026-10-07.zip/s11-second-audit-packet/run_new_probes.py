"""Reproducible second-audit measurements; original source/media are read-only."""
from __future__ import annotations
import os, sys, json, hashlib, copy
from pathlib import Path
from dataclasses import asdict, replace
from enum import Enum
ROOT = Path(os.environ.get('OIL_REPO', '/Users/sunjaekim/Developer/oil_level_tracker'))
OUT = Path(__file__).resolve().parent
sys.path[:0] = [str(ROOT), str(ROOT/'tests'), str(ROOT/'src')]
import cv2
import numpy as np
from paired_support import measure, summarize
from oil_tracker.adapters.vision.oil_supplemental_path import _phase_transition_profile
from oil_tracker.adapters.vision.opencv_phase_detector import OpenCvPhaseDetector
from oil_tracker.adapters.vision.geometry_masks import build_mask_bundle
from oil_tracker.adapters.vision.preprocessing import preprocess
from oil_tracker.adapters.storage.json_recipe_repository import JsonRecipeRepository
from oil_tracker.adapters.vision.oil_candidate_evidence import OilCandidateEvidence
from oil_tracker.adapters.vision.oil_candidate_authority import AuthorityContext, evaluate_candidate_authority
from oil_tracker.adapters.vision.oil_observation_resolver import OilObservationResolverConfig
from oil_tracker.domain.enums import BoundaryKind
from tests.diagnostics.s11_evidence_probe import load_cases, authoritative_input_hashes
from tests.test_r16_refactor_characterization import _sequence_candidate

def dump(name, value):
    def enc(x):
        if isinstance(x, Enum): return x.value
        if isinstance(x, np.generic): return x.item()
        raise TypeError(type(x).__name__)
    (OUT/name).write_text(json.dumps(value, indent=2, default=enc, allow_nan=False)+'\n', encoding='utf-8')

def main():
    pins = authoritative_input_hashes(ROOT)
    for sample, entries in pins.items():
        for suffix, digest in entries.items():
            assert hashlib.sha256((ROOT/'sample'/f'{sample}.{suffix}').read_bytes()).hexdigest()==digest
    controls=[]; h,w,row=96,100,48; x=np.arange(w)%20
    for mask_name,upper,lower in [('full',x>=0,x>=0),('shifted',x<12,x>=8),('disjoint',x<8,x>=12)]:
        for step in [0,30]:
            for polarity in [1,-1]:
                image=np.tile(np.where(x<10,80,170).astype(np.uint8),(h,1))
                image[row+1:]+=step
                if polarity<0:image=255-image
                visible=np.ones((h,w),bool);visible[:row]=upper;visible[row+1:]=lower
                original=(image.copy(),visible.copy())
                r,c,k,s=_phase_transition_profile(image,visible)
                measurement=measure(image,visible,row)
                np.testing.assert_array_equal(image,original[0]);np.testing.assert_array_equal(visible,original[1])
                controls.append({'mask':mask_name,'step':step,'polarity':polarity,
                    'legacy':{'response':float(r[row]),'coverage':float(c[row]),'consistency':float(k[row])},
                    'paired':summarize(measurement)})
    dump('footprint_controls.json',controls)
    cases=[(c.sample,c.frame_index,c.glass,c.video_path,c.truth_oil_y,'original') for c in load_cases(ROOT)]
    human_recipe=ROOT/'sample/output/s11-local-human-roi-comparison-001/sample4-human-roi.oilrecipe'
    glass=JsonRecipeRepository().load(human_recipe).glasses[0]
    cases += [('sample4',f,glass,ROOT/'sample/sample4.mp4',854.0 if f==420 else None,'human_roi') for f in [420,450,480]]
    results=[]; candidates=[]; frame_cards=[]
    for name,frame_index,glass,video,truth,recipe_role in cases:
        cap=cv2.VideoCapture(str(video),cv2.CAP_FFMPEG);assert cap.isOpened()
        cap.set(cv2.CAP_PROP_POS_FRAMES,frame_index);pos=cap.get(cv2.CAP_PROP_POS_FRAMES)
        ok,frame=cap.read();after=cap.get(cv2.CAP_PROP_POS_FRAMES);stamp=cap.get(cv2.CAP_PROP_POS_MSEC)/1000;cap.release()
        assert ok and pos==frame_index and after==frame_index+1
        detector=OpenCvPhaseDetector();d,art=detector.detect(frame,glass,frame_index,stamp,debug=True)
        before=copy.deepcopy(asdict(d));bundle=build_mask_bundle(frame,glass)
        pre=preprocess(bundle.crop,bundle.effective_mask,glass.detector_settings)
        visible=(bundle.effective_mask>0)&(pre.glare_mask==0);ox,oy=bundle.crop_origin
        key=f'{name}-{frame_index}-{recipe_role}'
        cv2.imwrite(str(OUT/(key+'-raw.png')),bundle.crop)
        frame_result={'case':key,'frame':frame_index,'timestamp':stamp,'truth':truth,'crop_origin':[ox,oy],
                      'raw_oil':d.raw_oil_air_level_y,'phase_candidates':[]}
        for index,candidate in enumerate(d.candidates):
            if candidate.kind is not BoundaryKind.OIL_AIR:continue
            local=int(round(candidate.y-oy))
            if not 0<=local<pre.gray.shape[0]:continue
            measurements={r:summarize(measure(image,visible,local)) for r,image in [('original',pre.gray),('normalized',pre.normalized)]}
            entry={'case':key,'candidate_input_index':index,'source':candidate.source,'source_y':candidate.y,
                   'local_row':local,'views':measurements}
            candidates.append(entry)
            if candidate.source=='phase_transition_scan':
                frame_result['phase_candidates'].append(entry)
        assert before==asdict(d)
        frame_result['detection_unchanged']=True
        results.append(frame_result)
        print('FRAME',key,'OIL',d.raw_oil_air_level_y,'PHASE',[(r['source_y'],r['views']['normalized']) for r in frame_result['phase_candidates']],flush=True)
    dump('real_frame_paired_support.json',{'input_pins':pins,'frames':results,'candidates':candidates})
    for sample, entries in pins.items():
        for suffix, digest in entries.items():
            assert hashlib.sha256((ROOT/'sample'/f'{sample}.{suffix}').read_bytes()).hexdigest()==digest
    print('PROBES_COMPLETE',len(results),'frames',len(candidates),'candidates',flush=True)

if __name__=='__main__':main()
