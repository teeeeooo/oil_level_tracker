"""Eight controlled latent-cause pairs; full candidate/sequence consumer comparison."""
import sys, os, json, copy
from pathlib import Path
ROOT=Path(os.environ.get('OIL_REPO','/Users/sunjaekim/Developer/oil_level_tracker'))
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'src')]
from oil_observability_fixtures import single_frame_observability_collisions
from oil_tracker.domain.recipe import InspectionRecipe
from oil_tracker.adapters.vision.opencv_phase_detector import OpenCvPhaseDetector
from paired_challenger import install

results=[]
for scene in single_frame_observability_collisions():
    item={'case':scene.case_id,'collision_id':scene.collision_id,'expected':'AMBIGUOUS','modes':{}}
    for mode in ['baseline','challenger']:
        undo=install() if mode=='challenger' else None
        try:
            glass=InspectionRecipe.default_glass(320,240)
            glass.id='controlled-collision';glass.geometry.ellipse=scene.ellipse
            detector=OpenCvPhaseDetector();raw=[]
            for index in range(6):
                d,_=detector.detect(scene.frame,glass,index,index*.5,debug=False)
                raw.append(d)
            done=detector.resolve_sequence(raw,glass,confirmed_initial_state=None)
            item['modes'][mode]={'raw_oil':[d.raw_oil_air_level_y for d in raw],
                'completed_oil':[d.raw_oil_air_level_y for d in done.detections],
                'candidate_universe':[[(c.source,c.y) for c in d.candidates] for d in raw]}
        finally:
            if undo:undo()
    before=item['modes']['baseline'];after=item['modes']['challenger']
    item['candidate_universe_equal']=before['candidate_universe']==after['candidate_universe']
    item['new_numeric_rows']=sum(a is None and b is not None
        for a,b in zip(before['completed_oil'],after['completed_oil'],strict=True))
    item['baseline_numeric_rows']=sum(v is not None for v in before['completed_oil'])
    item['challenger_numeric_rows']=sum(v is not None for v in after['completed_oil'])
    results.append(item)
    print(scene.case_id,item['baseline_numeric_rows'],item['challenger_numeric_rows'],
          item['new_numeric_rows'],item['candidate_universe_equal'],flush=True)
report={'schema':'s11-second-audit-collision-challenger-v1','cases':results,
    'new_numeric_total':sum(r['new_numeric_rows'] for r in results),
    'all_candidate_universes_equal':all(r['candidate_universe_equal'] for r in results),
    'limits':'Six repeated-frame synthetic sequences at 2fps; existing full resolver can differ from the earlier single-hypothesis ambiguity contract. No field labels.'}
(OUT/'collision_challenger.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
print('COLLISION_COMPLETE',report['new_numeric_total'],flush=True)
