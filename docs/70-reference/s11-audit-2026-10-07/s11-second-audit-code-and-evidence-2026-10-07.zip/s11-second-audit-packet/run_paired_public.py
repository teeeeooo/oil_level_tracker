"""Fresh four-video application replays, baseline versus one frozen challenger."""
import os, sys, json, subprocess, hashlib
from pathlib import Path
ROOT=Path(os.environ.get('OIL_REPO','/Users/sunjaekim/Developer/oil_level_tracker'))
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'src')]
from tests.diagnostics import s11_report_observability_replay as replay
from tests.diagnostics.s11_observation_replay_audit import tracking_rows, sequence_audit, user_truth_audit
from paired_challenger import install, COUNTS

def main():
    if len(sys.argv)==3:
        mode,name=sys.argv[1:]
        if mode=='challenger':install()
        replay.QUALIFICATION_WINDOWS={name:replay.QUALIFICATION_WINDOWS[name]}
        replay.run_replay(root=ROOT,output_root=OUT/f'paired-public-{mode}'/name,
            verify_accepted_counts=False,expected_numeric_oil_counts=None,
            expected_tracking_fingerprints=None,run_label=f'S11 second audit {mode}',
            run_note='Exposed regression characterization; external scorer identified separately; not field acceptance',
            manifest_schema='s11-second-audit-public-v1')
        (OUT/f'{mode}-{name}-scorer-counts.json').write_text(json.dumps(COUNTS),encoding='utf-8')
        return
    results={}
    for mode in ['baseline','challenger']:
        results[mode]={}
        for name in replay.QUALIFICATION_WINDOWS:
            subprocess.run([sys.executable,str(Path(__file__)),mode,name],cwd=ROOT,
                           check=True,stdin=subprocess.DEVNULL)
            path=OUT/f'paired-public-{mode}'/name/'replay_manifest.json'
            item=json.loads(path.read_text(encoding='utf-8'))['samples'][0]
            rows=tracking_rows(Path(item['bundle']))
            audit=sequence_audit(rows)
            assert audit['numeric_without_same_frame_provenance']==0
            assert item['tracking_row_count']==replay.ACCEPTED_ROW_COUNTS[name]
            results[mode][name]={'manifest':item,'sequence':audit,
                'truth':user_truth_audit(ROOT,name,rows)}
            print(mode,name,json.dumps(results[mode][name]),flush=True)
            (OUT/'paired_public_progress.json').write_text(json.dumps(results,indent=2,allow_nan=False),encoding='utf-8')
    report={'schema':'s11-second-audit-paired-public-v1','results':results,
        'external_scorer_sha256':hashlib.sha256((OUT/'paired_challenger.py').read_bytes()).hexdigest(),
        'measurement_sha256':hashlib.sha256((OUT/'paired_support.py').read_bytes()).hexdigest(),
        'plan_sha256':hashlib.sha256((OUT/'challenger-plan.json').read_bytes()).hexdigest(),
        'limits':'Source-head alone does not identify challenger. External scorer and fixed plan are mandatory provenance. No historical golden acceptance, calibration or independent holdout.'}
    (OUT/'paired_public_results.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    print('PAIRED_PUBLIC_COMPLETE',flush=True)

if __name__=='__main__':main()
