import copy
import json
import numpy as np
import pytest
from paired_support import measure, summarize
from oil_tracker.adapters.vision.oil_supplemental_path import _phase_transition_profile


def arrays(mask='shifted', step=0, reverse=False):
    x=np.arange(100)%20
    gray=np.tile(np.where(x<10,80,170).astype(np.uint8),(96,1))
    gray[49:]+=step
    if reverse:gray=255-gray
    visible=np.ones(gray.shape,bool)
    if mask=='shifted':visible[:48]=x<12;visible[49:]=x>=8
    if mask=='disjoint':visible[:48]=x<8;visible[49:]=x>=12
    return gray,visible


@pytest.mark.parametrize('mask',['full','shifted','disjoint'])
@pytest.mark.parametrize('step',[0,30])
@pytest.mark.parametrize('reverse',[False,True])
def test_matched_columns_remove_sampling_bias_not_vertical_step(mask,step,reverse):
    gray,visible=arrays(mask,step,reverse)
    before=[gray.copy(),visible.copy()]
    result=measure(gray,visible,48)
    for row in result['measurements']:
        expected=None if mask=='disjoint' else float(-step if reverse else step)
        assert row['paired_mean_delta']==expected
        assert row['paired_median_delta']==expected
    assert len(result['measurements'])==15
    assert result['identity']=='UNRESOLVED' and result['scalar'] is None
    assert result['observed_boundary_support'] is None
    assert result['static_opposition'] is None
    json.dumps(result,allow_nan=False)
    np.testing.assert_array_equal(gray,before[0]);np.testing.assert_array_equal(visible,before[1])
    if step==0:
        response,coverage,consistency,_=_phase_transition_profile(gray,visible)
        assert response[48]==(0 if mask=='full' else 1)
        assert coverage[48]==1
        assert consistency[48]==(0 if mask=='full' else 1)


@pytest.mark.parametrize('kind',['dtype','mask_dtype','shape','row','bound'])
def test_invalid_rasters_rejected(kind):
    gray,visible=arrays();row=48
    if kind=='dtype':gray=gray.astype(float)
    elif kind=='mask_dtype':visible=visible.astype(np.uint8)
    elif kind=='shape':visible=visible[:-1]
    elif kind=='row':row=96
    else:gray=np.zeros((1025,2),np.uint8);visible=np.ones(gray.shape,bool)
    with pytest.raises(ValueError):measure(gray,visible,row)


def test_censored_row_is_not_clean_zero():
    gray,visible=arrays()
    result=measure(gray,visible,0)
    assert all(r['paired_mean_delta'] is None for r in result['measurements'])
    assert all(r['paired_mean_response'] is None for r in summarize(result))
