# S11 second audit — 2026-10-07

Base: 9f41d2f8a517da21f570f57ed1b4e2009a9d48db.
This is a lightweight evidence and code packet, not a production release.

- a0b-test-contract.patch changes only three test files. It was tested in a detached worktree and has NOT been applied to main.
- Completed canonical selections: 2072 non-Qt + 254 Qt = 2326 distinct cases. An initial Qt run stalled; the native stack evidence is retained. One full retry and three focused preflight retries passed. The Qt stability issue is NOT repaired.
- paired_challenger.py is one rejected-for-adoption experiment. Do not install it in production. It does not fix the known frame420 Y821 selection.
- Sample3 Oil rows change 29 -> 27: seven new numeric rows and nine withdrawals, not merely two withdrawals. Sparse legacy truths are unchanged.
- Scripts require the pinned repository, original sample inputs and, for the saved-sequence test, the existing human ROI and saved raw JSON.
- Run scripts from a NEW directory. Their output root is the script directory; reusing an old directory can overwrite experiment outputs.
- Set OIL_REPO to the repository and use its .venv/bin/python, PYTHONDONTWRITEBYTECODE=1, QT_QPA_PLATFORM=offscreen. Put OIL_REPO/src, OIL_REPO/tests, OIL_REPO and the new script directory on PYTHONPATH for standalone pytest.
- No field qualification, independent holdout, classifier fitting, new physical labels, or media export from the private Windows PC was performed.

The full source-frame PNGs, 377-candidate measurements, full JUnit XML, logs and all eight replay bundles remain in the durable Mac copy:
/Users/sunjaekim/Developer/oil_level_tracker/sample/output/s11-second-audit-20261007-001

The original run root was /tmp/s11-second-audit-20261007-jtt0irop. Embedded artifact paths retain that execution provenance. Resolve copied artifact locations by replacing this prefix with the durable root; source media paths remain unchanged.

This code-and-summary ZIP contains scripts, the test patch, a curated delivery-summary.json and score/control summaries only. Full execution-summary.json, final_receipt.json, JUnit, logs, PNGs, candidate data and bundles are in the durable Mac copy. delivery-manifest.json hashes the included files (excluding itself).
