"""Trace existing score contributions and signed-pair information without changing returns."""
import os,sys,json,copy,inspect,hashlib
from pathlib import Path
from dataclasses import asdict
from enum import Enum
ROOT=Path(os.environ.get('OIL_REPO','/Users/sunjaekim/Developer/oil_level_tracker'))
OUT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'tests'),str(ROOT/'src')]
import cv2
import numpy as np
from oil_tracker.adapters.storage.json_recipe_repository import JsonRecipeRepository
from oil_tracker.adapters.vision.opencv_phase_detector import OpenCvPhaseDetector
import oil_tracker.adapters.vision.oil_shadow_observations as obs

recipe=ROOT/'sample/output/s11-local-human-roi-comparison-001/sample4-human-roi.oilrecipe'
glass=JsonRecipeRepository().load(recipe).glasses[0]
cap=cv2.VideoCapture(str(ROOT/'sample/sample4.mp4'),cv2.CAP_FFMPEG)
cap.set(cv2.CAP_PROP_POS_FRAMES,420);ok,frame=cap.read();assert ok
stamp=cap.get(cv2.CAP_PROP_POS_MSEC)/1000;cap.release()
baseline,_=OpenCvPhaseDetector().detect(frame,glass,420,stamp,debug=True)
semantic_original=obs._semantic_hypothesis;narrow_original=obs._narrow_summary
semantic_records=[];narrow_records=[]

def narrow(proposal,context,bounds):
    snapshots={k:v.copy() for k,v in context.items()}
    result=narrow_original(proposal,context,bounds)
    center=min(len(context['signed'])-1,max(0,int(round(proposal.representative_local_y))))
    partner=int(round(center+2*result.center_offset_px))
    for key,value in context.items():np.testing.assert_array_equal(value,snapshots[key])
    paired=result.paired_edge_separation_px>=2 and result.paired_edge_strength>0
    valid=paired and context['valid'][center]>0 and context['valid'][partner]>0
    left=float(context['signed'][center]) if valid else None
    right=float(context['signed'][partner]) if valid else None
    narrow_records.append({'proposal':proposal.identity,'center':center,'partner':partner,
        'legacy':asdict(result),'signed_center':left,'signed_partner':right,
        'sign_relation':None if not valid or left==0 or right==0 else ('same' if left*right>0 else 'opposite')})
    return result


def semantic(*args,**kwargs):
    inputs=inspect.signature(semantic_original).bind(*args,**kwargs).arguments
    result=semantic_original(*args,**kwargs)
    n=inputs['narrow'];b=inputs['broad'];s=inputs['static_prior']
    pulse=obs._narrow_pulse_artifact(n)
    structural=obs._unit(.58*pulse+.18*n.static_overlap+.12*(1-b.scale_consistency)+.12*(1-b.polarity_consistency))
    plateau=obs._scoped_plateau_collision_artifact(inputs['bright_plateau_artifact'],b,n)
    terms={'broad':.55*b.strength,'narrow':.25*obs._narrow_boundary_support(n),
           'polarity':.12*result.polarity_confidence,'visibility':.08*result.visibility,
           'pulse_subtraction':-.16*pulse,'static_subtraction':-.08*s.contribution}
    artifact_terms={'structural_after_broad_relief':structural*(1-.82*b.strength),
                    'static_contribution':s.contribution,'plateau_collision':plateau}
    assert abs(obs._unit(sum(terms.values()))-result.boundary_likelihood)<1e-12
    assert abs(obs._unit(sum(artifact_terms.values()))-result.artifact_likelihood)<1e-12
    semantic_records.append({'hypothesis':result.identity,'source_y':result.representative_source_y,
        'proposal_ids':result.proposal_ids,'boundary':result.boundary_likelihood,
        'artifact':result.artifact_likelihood,'boundary_terms':terms,'artifact_terms':artifact_terms,
        'pulse_artifact':pulse,'bright_plateau_artifact':inputs['bright_plateau_artifact'],
        'broad':asdict(b),'narrow':asdict(n)})
    return result

obs._narrow_summary=narrow;obs._semantic_hypothesis=semantic
try:
    traced,art=OpenCvPhaseDetector().detect(frame,glass,420,stamp,debug=True)
finally:
    obs._narrow_summary=narrow_original;obs._semantic_hypothesis=semantic_original
assert asdict(baseline)==asdict(traced)
report={'schema':'s11-score-lineage-inspection-v1','source_frame':420,'detection_equal':True,
    'semantics':semantic_records,'narrow':narrow_records,
    'final_candidates':[asdict(c) for c in traced.candidates],
    'limits':'Read-only intermediate raw hypothesis terms; post-merge candidate identity is checked separately, not assumed from proximity.'}
def enc(x):
    if isinstance(x,Enum):return x.value
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
(OUT/'score_lineage.json').write_text(json.dumps(report,indent=2,default=enc,allow_nan=False),encoding='utf-8')
for row in semantic_records:
    if abs(row['source_y']-854)<3:print(json.dumps(row,default=enc),flush=True)
print('LINEAGE_COMPLETE',len(semantic_records),len(narrow_records),flush=True)
