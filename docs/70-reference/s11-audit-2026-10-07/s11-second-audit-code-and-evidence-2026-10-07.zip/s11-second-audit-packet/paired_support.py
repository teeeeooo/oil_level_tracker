"""Bounded shadow measurements; no physical identity or scalar output."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from hashlib import sha256
import numpy as np

RADII = (3, 6, 10)
SECTORS = 5

@dataclass(frozen=True)
class SectorMeasurement:
    radius: int
    sector: int
    first_x: int
    last_x: int
    upper_pixels: int
    lower_pixels: int
    paired_columns: tuple[int, ...]
    pooled_delta: float | None
    paired_mean_delta: float | None
    paired_median_delta: float | None
    upper_x_mean: float | None
    lower_x_mean: float | None

def measure(gray: np.ndarray, visible: np.ndarray, row: int) -> dict:
    """Compare original pooling with symmetric same-column samples.

    A paired column has every +/-1..radius sample visible. Values are DN,
    not probabilities. Absent support is None, not zero. This horizontal
    row descriptor is not a native curved-path measurement.
    """
    if gray.ndim != 2 or gray.dtype != np.uint8:
        raise ValueError("gray must be two-dimensional uint8")
    if visible.shape != gray.shape or visible.dtype != np.bool_:
        raise ValueError("visible must be matching bool mask")
    height, width = gray.shape
    if height > 1024 or width > 1024:
        raise ValueError("shadow raster bound exceeded")
    if not isinstance(row, (int, np.integer)) or not 0 <= row < height:
        raise ValueError("row must be a valid local integer row")
    edges = np.linspace(0, width, SECTORS+1, dtype=int)
    measurements = []
    for radius in RADII:
        for sector, (first, last) in enumerate(zip(edges[:-1], edges[1:])):
            if row-radius < 0 or row+radius >= height:
                measurements.append(SectorMeasurement(radius, sector,
                    int(first), int(last), 0, 0, (), None, None, None, None, None))
                continue
            upper = gray[row-radius:row, first:last].astype(np.float64)
            lower = gray[row+1:row+radius+1, first:last].astype(np.float64)
            um = visible[row-radius:row, first:last]
            lm = visible[row+1:row+radius+1, first:last]
            uc, lc = int(um.sum()), int(lm.sum())
            common = um.all(axis=0) & lm.all(axis=0)
            xs = np.flatnonzero(common)
            values = (lower[:, common].mean(axis=0)-upper[:, common].mean(axis=0)
                      if xs.size else None)
            pooled = float(lower[lm].mean()-upper[um].mean()) if uc and lc else None
            ux = float(np.nonzero(um)[1].mean()+first) if uc else None
            lx = float(np.nonzero(lm)[1].mean()+first) if lc else None
            measurements.append(SectorMeasurement(radius, sector,
                int(first), int(last), uc, lc, tuple(int(x+first) for x in xs), pooled,
                None if values is None else float(values.mean()),
                None if values is None else float(np.median(values)), ux, lx))
    return {"schema": "s11-paired-footprint-shadow-v1", "local_row": int(row),
        "shape": list(gray.shape), "gray_sha256": sha256(gray.tobytes()).hexdigest(),
        "visible_sha256": sha256(visible.tobytes()).hexdigest(),
        "measurements": [asdict(m) for m in measurements],
        "identity": "UNRESOLVED", "scalar": None,
        "static_opposition": None, "observed_boundary_support": None}


def summarize(result: dict) -> list[dict]:
    rows = []
    for radius in RADII:
        measurements = [v for v in result["measurements"] if v["radius"] == radius]
        pooled = [abs(v["pooled_delta"])/48 for v in measurements if v["pooled_delta"] is not None]
        paired = [abs(v["paired_mean_delta"])/48 for v in measurements if v["paired_mean_delta"] is not None]
        med = [abs(v["paired_median_delta"])/48 for v in measurements if v["paired_median_delta"] is not None]
        rows.append({"radius": radius, "pooled_sectors": len(pooled), "paired_sectors": len(paired),
            "pooled_response": None if len(pooled)<3 else min(1.0, float(np.median(pooled))),
            "paired_mean_response": None if len(paired)<3 else min(1.0, float(np.median(paired))),
            "paired_median_response": None if len(med)<3 else min(1.0, float(np.median(med)))})
    return rows
