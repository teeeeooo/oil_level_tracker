# S11 continuation execution evidence — 2026-10-07

Baseline: `9f41d2f8a517da21f570f57ed1b4e2009a9d48db`.
Scope: isolated local experiments, not a Windows field result.
S11 ACTIVE / W4 OPEN / O2 unpromoted / existing FIELD FAIL remain unchanged.

## Detector Governance

- Logic-map nodes: `OIL-HYPOTHESIS`, `OIL-AUTHORITY`, `OIL-TRACKLET`, `OIL-PHASE-FILL`, `OIL-SELECTOR`, `OIL-PROJECTION`
- Failure-registry entries: `S11-F01`, `S11-F02`, `S11-F03`, `S11-F05`, `S11-F08`, `S11-F09`, `S11-F10`
- First harmful stage: the P2 sample3/frame1035 observation is retained through candidate authority and tracklet admission, then rejected by the historical-only confirmation-profile predicate at OIL-PHASE-FILL. The correct physical identity of unlabelled extra observations remains unknown; candidate count is not an accuracy result.
- Logic-map impact: NONE — current deployed ownership topology is retained and the replacement is isolated; neither the main branch nor the map has been changed.
- Failure-registry impact: NONE — local counterexamples strengthen existing guards without qualifying the field or creating a new deployed mechanism.

## Executed development experiments

- Fixed-raw cadence: for the same sample4/frame420 candidates, strides 1/2/3/5/10/15 return Oil Y821/absent/Y821/absent/Y852/Y852. P3C preserves these results; it does not solve cadence sensitivity.
- P1 signed opposite-lobe separation: 75/80 focused tests pass; unresolved bright-texture controls regress. Rejected.
- P2 conservative optical-domain guard: 79/80 focused tests and 594 broader tests pass. The fixed 299-row application replay changes numeric Oil from162 to197, but loses sample3/frame1035 Y244. Rejected.
- P3 broad recent-profile renewal: the lost Y244 is restored on the exact P2 raw sequence, but the baseline application gains an unlabelled sample4/frame1290 Y836. Not adopted as an accuracy improvement.
- P3C repeated-anchor-only renewal: preserve original confirmation history; require the incumbent recent `ANCHOR_CORRIDOR` rather than a single anchor plus motion. Cached counterfactuals restore Y244 and remove the broad P3 addition without modifying candidate positions.
- P4 affine-ramp/localized-step separation: 10 signed synthetic controls and14 exposed image cases characterized. Numeric Oil rises to258/299 while all13 existing truth-case results remain unchanged. More numeric output is not accepted as better detection.

P2 and P4 additional sample3 rows were decoded for deterministic visual
review (six evenly spaced additions per variant). Several predictions align
with rim-adjacent or internal appearance structures. No physical-truth label,
accuracy percentage or tolerance was manufactured from these panels.

## Final P3C source and completed regression checks

Source changes are restricted to three vision modules and16 new tests in
`tests/unit/test_oil_recent_anchor_witness.py`. The original checkout remains
at the baseline; the worktree implementation is not a deployed replacement.

The fixed operating-window application replay completed all299 rows across
four videos. P3C retains162 numeric Oil rows,31 numeric Foam rows and the
same11/13 legacy truth-point returns. Every tracking field except the run
identifier is equal to baseline, including confidence, state and flags.
No same-frame numeric provenance violation was found. This is a non-regression
result, not an accuracy gain. On the exact P2 sample3 raw packet, the genuine
unwrapped P3C resolver restores only frame1035/Y244; the rest of its numerical
outputs remain unchanged from that packet.

Final non-Qt suite with the local media present:2072 passed,3 failed,0 skipped.
Completed Qt rerun:254 passed. Combined:2326 passed,3 failed of2329 tests.
All16 added cases pass. The three failure IDs and both actual legacy
fingerprints exactly match the earlier baseline failures; goldens were not
rewritten. The test-file encoding violations also remain unchanged.

One initial Qt run stalled after241 completed tests. The OS stack sample
records a Qt mutex wait during signal connection with QThread cleanup active.
The root cause was not established; a clean full Qt rerun passed. This incident
is preserved rather than silently counted as a successful run.

## Input-end verification and widened application context

Sequential OpenCV decoding reads6601 source frames in total versus6608 frames
reported in metadata: Base434/434, sample2 286/288, sample3 4199/4202 and
sample4 1682/1684. The unavailable tail counts are observations for this
backend, not a claim that every other decoder must behave identically.

A metadata-end full-video run fails at sample3/140.173s for both baseline and
P3C. These failed attempts are retained separately. A Base terminal timestamp
seek also reports frame434 where sequential decoding ended at frame433;
therefore metadata and timestamp seeking are not silently treated as exact
frame-identity truth at that boundary.

The widened A/B protocol uses every2fps regular-grid target through the
verified decoded extent: requested ends14.0,9.5,140.0 and56.0 seconds. It does
not force an off-grid terminal request or modify source media/recipes, and it
does not fabricate a replacement for undecodable tail frames. Completed
widened results are summarized with their own denominator, not compared with
the299-row count as if the difference were an accuracy improvement.

All P1/P2/P3/P3C/P4 labels in this record refer to this dated continuation;
they do not rename older production experiments with similar identifiers.
Raw captures, bundles, image panels, scripts, logs and source hashes remain
in the isolated worktree's `continuation-results/` directory. The compact
execution receipt accompanies the patch. No new human truth, tolerance,
Windows evidence, O2 promotion, main commit or push was created.

## Completed widened A/B result

| Video | Requested end (s) | Rows | Baseline numeric Oil | P3C numeric Oil | Changed public rows |
|---|---:|---:|---:|---:|---:|
| base_sample_1 |14.0|29|27|27|0|
| sample2 |9.5|20|13|13|0|
| sample3 |140.0|281|107|107|0|
| sample4 |56.0|113|101|101|0|
| Total |—|443|248|248|0|

The443-row comparison includes every public tracking field except run identity;
Oil, Foam, confidence, state and flags all match. Both runs finish successfully
on this explicitly defined protocol with no numeric same-frame provenance
violation. The source hashes are unchanged from the final P3C freeze through
all completed tests and application replays. The original756 tracked files
also remain byte-identical and the original worktree is clean.

Conclusion: a reproducible structural counterfactual repair and a non-regressing
isolated patch were obtained. An increase in physical detector accuracy was
not demonstrated. The broader P3's extra row is unlabelled, not proven false;
its promotion was withheld. P1/P2/P4 are not replacement candidates under the
observed controls. Existing field failures, O2 status and W4 remain unchanged.
