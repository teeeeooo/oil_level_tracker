# S11 bounded anchor reconfirmation — implemented experimental candidate

Date: 2026-10-07
Baseline: `9f41d2f8a517da21f570f57ed1b4e2009a9d48db`
Status: isolated P3C candidate; not merged, not field-qualified, not an O2 promotion.

## History Review

- Logic-map nodes: `OIL-TRACKLET`, `OIL-PHASE-FILL`, `OIL-SELECTOR`, `OIL-PROJECTION`
- Failure-registry entries: `S11-F03`, `S11-F05`, `S11-F08`, `S11-F09`
- Prior mechanisms reviewed: R10/R11 motion-only bootstrap failure; R18/R21 bounded ownership and current material-anchor handoff; current `_finalize_track` historical confirmation and `_is_current_fill_anchor_handoff` contracts; the October 7 pulse and localization counter-experiments.
- Prior mechanisms rejected: no blanket source demotion, motion-only anchor promotion, retrospective coordinate publication, owner-ID copying, unconstrained barrier reopening, sample-coordinate correction, or truth/golden edits.
- Preserved contracts: the original confirmation profile and historical trajectory remain unchanged; existing admission, loss, geometry, motion, material-anchor and ambiguity requirements remain in force; output is always an existing same-frame candidate.
- Difference from prior failures: expose the already-computed bounded recent-window profile separately from historical confirmation. Only an existing repeated-anchor corridor may renew the current handoff witness; a single anchor plus motion cannot renew it.
- Logic-map impact: NONE — the deployed baseline and ownership topology are unchanged; this isolated implementation remains a review candidate inside the existing tracklet-to-fill handoff boundary.
- Failure-registry impact: NONE — this is a bounded local recurrence of F03/F08 with no new field result or change to existing failure status.

## Observed mechanism and counterfactual

In the frozen sample3 application replay, the pulse-domain experiment P2
changed an early tracklet confirmation from `ANCHOR_TRAJECTORY` to
`MOTION_TRAJECTORY`. At frame 1035, the material-path candidate at Y244
still had `ANCHOR_ELIGIBLE` authority, and the current bounded window had
repeated anchors. The historical-only handoff predicate nevertheless rejected
it. Instrumented replay reproduced the entire completed output before the
predicate was changed. P3C restores this candidate on P2 raw observations;
it does not claim that P2's other new observations are correct.

## Implemented replacement

1. `oil_sequence_types.py`: add neutral-default `tracklet_recent_confirmation_profile`.
2. `oil_interface_tracklets.py`: populate it from the cached bounded current-window evidence, only when the window is ready and the observation is compatible.
3. `oil_phase_lifecycle.py`: retain the historical anchor route. Add a current-window route only when the frame identity and window end match and the recent profile is `ANCHOR_CORRIDOR`.

No threshold, candidate position, source-family allowlist, initial state, output
schema, learned image model or main workplan was changed. No history profile
is overwritten by the new field. The new field is internal evidence, not a
new reported measurement.

## Why the broader P3 was not retained

Allowing a recent `ANCHOR_TRAJECTORY` as well as `ANCHOR_CORRIDOR` added an
unlabelled sample4 observation at frame1290/Y836. This was not accepted as a
recall gain. Its recent witness combined one anchor with motion; the restored
sample3 row instead had a repeated-anchor corridor. P3C therefore requires
independent repeated anchor observations for renewal, using the incumbent
corridor rule, not a new numeric threshold. This distinction was developed
on exposed cases and is not an independent validation result.

## Boundaries and acceptance

The initial FULL/EMPTY restrictions, completed-material barrier, physical
tracklet IDs, current material-path anchor requirement and ordinary geometry
checks remain unchanged. Current-window absence, a stale/future window,
incompatible or unadmitted observations, motion-only confirmation and a
single-anchor trajectory cannot use the new route. Historical anchor routes
retain their previous behavior.

The new tests exercise generated motion-first/anchor-later history, bounded
expiry and the positive/negative handoff cases. Full-suite and application
receipts are recorded in the companion evidence file. An unchanged baseline
measurement table is a regression result, not evidence of improved accuracy.
