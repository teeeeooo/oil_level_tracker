from dataclasses import replace
from types import SimpleNamespace

import pytest

from unit import test_oil_interface_tracklets as tracks
from unit import test_oil_phase_lifecycle as phase
from oil_tracker.adapters.vision.oil_candidate_authority import OilCandidateAuthority as Authority
from oil_tracker.adapters.vision.oil_interface_tracklets import DirectedInterfaceTrackletBuilder
from oil_tracker.adapters.vision.oil_phase_lifecycle import OilMaterialPhaseLifecycleOwner
from oil_tracker.adapters.vision.oil_sequence_types import TrackletConfirmationProfile as Profile


def test_recent_anchor_witness_does_not_rewrite_motion_first_history():
    rows = tuple((tracks._ref(frame, 0, 150.0-frame*4,
        authority=Authority.ANCHOR_ELIGIBLE if frame in (5,6) else Authority.CONTINUATION_ELIGIBLE,
        source='oil_hypothesis:test', motion=0.9, coverage=0.9),) for frame in range(14))
    result = DirectedInterfaceTrackletBuilder(tracks._policy()).resolve(rows)
    refs = [row[0] for row in result.refs_by_frame]
    assert refs[2].tracklet_confirmation_profile is Profile.MOTION_TRAJECTORY
    assert all(r.tracklet_confirmation_profile is Profile.MOTION_TRAJECTORY for r in refs[2:])
    assert refs[6].tracklet_recent_confirmation_profile is Profile.ANCHOR_CORRIDOR
    assert refs[0].tracklet_recent_confirmation_profile is Profile.NONE
    assert refs[1].tracklet_recent_confirmation_profile is Profile.NONE
    assert refs[4].tracklet_recent_confirmation_profile is Profile.MOTION_TRAJECTORY
    assert refs[13].tracklet_recent_confirmation_profile is Profile.MOTION_TRAJECTORY
    assert all(r.tracklet_recent_window_end_frame == r.frame_offset for r in refs)


@pytest.mark.parametrize('case,expected', [
    ('fresh', True), ('historical', True), ('none', False), ('motion_only', False),
    ('single_anchor_trajectory', False),
    ('stale', False), ('future', False), ('wrong_frame', False), ('unadmitted', False),
    ('incompatible', False), ('low_motion', False), ('ordinary', False),
    ('continuation', False), ('distant', False), ('reversed', False)])
def test_current_anchor_handoff_requires_its_own_fresh_bounded_proof(case, expected):
    owner = OilMaterialPhaseLifecycleOwner(phase._policy())
    node = phase._node(3, 'fresh-owner', 120.0, direction=-1, progress=12.0,
        confirmation_profile=Profile.MOTION_TRAJECTORY, motion_support=0.9,
        motion_coverage=0.9, material_path=(case != 'ordinary'),
        authority=Authority.CONTINUATION_ELIGIBLE if case=='continuation' else Authority.ANCHOR_ELIGIBLE)
    changes = {'tracklet_recent_confirmation_profile': Profile.ANCHOR_CORRIDOR,
               'tracklet_recent_window_end_frame': 3}
    if case == 'historical':
        changes.update(tracklet_confirmation_profile=Profile.ANCHOR_TRAJECTORY,
                       tracklet_recent_confirmation_profile=Profile.NONE)
    if case == 'none': changes['tracklet_recent_confirmation_profile'] = Profile.NONE
    if case == 'motion_only': changes['tracklet_recent_confirmation_profile'] = Profile.MOTION_TRAJECTORY
    if case == 'single_anchor_trajectory': changes['tracklet_recent_confirmation_profile'] = Profile.ANCHOR_TRAJECTORY
    if case == 'stale': changes['tracklet_recent_window_end_frame'] = 2
    if case == 'future': changes['tracklet_recent_window_end_frame'] = 4
    if case == 'wrong_frame': changes['frame_offset'] = 2
    if case == 'unadmitted': changes['tracklet_admitted'] = False
    if case == 'incompatible': changes['tracklet_incompatible'] = True
    if case == 'low_motion': changes['tracklet_motion_support'] = 0.0
    node = replace(node, candidate_ref=replace(node.candidate_ref, **changes))
    row = owner._rows((node,))[0]
    if case == 'distant': row = replace(row, y=10.0)
    if case == 'reversed': row = replace(row, y=160.0)
    chain = SimpleNamespace(last=SimpleNamespace(frame=1, y=140.0))
    assert owner._is_current_fill_anchor_handoff(chain, row, 3) is expected
