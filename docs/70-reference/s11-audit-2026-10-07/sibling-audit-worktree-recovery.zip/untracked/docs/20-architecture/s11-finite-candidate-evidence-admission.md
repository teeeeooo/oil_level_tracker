# S11 finite candidate-evidence admission

## Scope and authority

This is a review candidate implemented only in the detached audit worktree based
on `9f41d2f8a517da21f570f57ed1b4e2009a9d48db`. It supplements the existing
[R22 ownership contract](s11-r22-oil-ownership-evidence-replacement-architecture.md);
it does not introduce a new detector version, authorize integration, or replace
[the current work-plan gate](../00-project/work-plan.md).

The patch closes a malformed-scalar fail-open path. It is not an Oil/Foam image
recognition improvement and does not establish Windows effectiveness.
The experiment results and handoff belong to the
[dated audit](../50-diagnostics/s11/2026-10-07-execution-audit-and-handoff.md).

## History Review

- Logic-map nodes: `OIL-CANDIDATE`, `OIL-AUTHORITY`, `FOAM-IDENTITY`, `OIL-PROJECTION`, `CSV-PUBLICATION`.
- Failure-registry entries: `S11-F01`, `S11-F02`, `S11-F06`, `S11-F09`, `S11-F10`.
- Prior mechanisms reviewed: the current logic map and the cited failure entries; R22 typed availability/admission; raw-versus-completed provenance; the October 6–7 producer/pulse counter-controls.
- Prior mechanisms rejected: clipping unknown opposition into measured-clean evidence, motion-only authority, blanket source-family demotion, global material veto, threshold relaxation, and truth/Y/time-specific branches.
- Preserved contracts: original finite-input behavior; unavailable versus measured evidence; hard-invalid admission; independent Oil/Foam publication; no interpolation/carry; same-frame candidate/sequence/CSV Y equality; unchanged historical goldens.
- Difference from prior failures: present malformed decision inputs are rejected before clipping/eligibility, rather than compensated by stronger scores or later sequence continuity. The raw scalar check also protects cached corroborating peers.
- Logic-map impact: NONE — existing evidence, identity, authority, and observation-only material owners retain their responsibilities and order.
- Failure-registry impact: NONE — this enforces the existing F01/F02/F06/F09/F10 prevention contracts; no new lifecycle or physical failure class is asserted.

## Reproduced defect

A candidate with explicit `sequence_eligible=1` and `NaN` artifact, optical,
material-texture, or visibility evidence could remain `ANCHOR_ELIGIBLE`.
The normalization layer clipped non-finite/unparseable inputs to zero while
availability was inferred from key presence. `max()` over malformed raw optical
values could also raise during evidence-index construction. Normalized cached
peer evidence did not independently protect the raw candidate after mutation.

## Candidate scalar contract

`invalid_candidate_evidence_fields` validates finite `y`, `feature_score`,
`penalty`, and `final_score`, plus explicitly enumerated decision-bearing feature
and penalty keys and their compatibility aliases. It returns deterministic
field paths. Present `NaN`, either infinity, `None`, and unparseable scalars are
invalid. Overflow during conversion is invalid as well.

Absent optional measurements keep their existing availability semantics.
Arbitrary diagnostic strings/optional metadata are not parsed as authority.
Finite out-of-range inputs keep the existing clipping behavior; this is not a
new range-policy or calibration change. Feature dictionaries are not mutated.

The guard is evaluated against the raw candidate even when a normalized evidence
object is supplied from the index. A cached view cannot authorize a now-invalid
candidate. The key inventory is deliberately bounded and must be extended with
future decision-bearing aliases and corresponding negative controls.

## Existing owner integration

- `candidate_is_eligible`: fail before explicit sequence eligibility.
- `evaluate_phase_identity`: no independent identity; expose `finite:<field>`
  predicates. The `CONTINUATION_ONLY` identity label is not permission to admit
  the candidate: authority below is hard-invalid.
- `evaluate_candidate_authority`: `HARD_INVALID / INELIGIBLE`, with the same
  explicit malformed-field predicates. No threshold or positive route changes.
- Cross-representation support: existing peer eligibility now rejects malformed
  raw evidence even when its cached normalized view previously looked clean.
- `track_foam_material_identity`: invalid candidate geometry cannot seed the
  observation-only context; invalid Oil evidence cannot continue or contribute
  material opposition. Actual Foam episode/publication policy is unchanged.

Optical normalization takes the maximum of individually normalized scalars.
For finite inputs this equals normalizing their raw maximum; 36 finite pair
controls preserve that algebraic contract. It prevents an indexing exception,
while the raw-input guard—not the normalized zero—owns rejection.

Context/configuration validation, all malformed trace serialization, numeric
range tightening, and the interpretation of absent legacy fields are outside
this patch. Do not describe this as validation of every possible runtime input.

## Regression-contract maintenance

The original current-frame, R21, and R20 golden hash constants remain unchanged.
Only the enumerated additive Foam diagnostic namespace/label raster are removed
from the predecessor current-frame view; their presence/type and independent
trace round-trips remain tested.
The corrected phase diagnostic is bridged only for the exact string
`boundary;boundary_advantage;localized_boundary` at four named diagnostic fields.
The current string is asserted before bridging; unknown/partial/new strings,
coordinates, scores, authority, selected members and identity remain visible to
the predecessor fingerprint. Mutation controls enforce that separation.

Test text I/O explicitly declares UTF-8. No test-authoring policy is waived.

## Review and integration obligations

The acceptance evidence must include malformed-input red/green controls, cached
peer and repeated-sequence controls, finite optics parity, full finite-input
result equality, the unchanged predecessor fingerprints, full non-Qt/Qt suites,
source/test freeze verification, protected corpus/recipe/truth hashes, and the
mechanical detector-governance check. Test counts and actual outcomes belong in
the dated audit, not in this durable contract.

No experimental shared-score, raster-score, or signed-lobe implementation is
part of this patch. Those challengers live outside the worktree in a separate
results directory and must not be copied into production as a side effect of
integrating this guard. A producer/identity redesign requires its own frozen
candidate, two-sided controls, exact-frame comparison, independent evaluation,
and the existing Windows acceptance path. Passing this guard's tests closes
neither W4/O2 nor S11, and authorizes no commit, push, merge, or field PASS.
