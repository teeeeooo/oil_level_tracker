from __future__ import annotations

from copy import deepcopy
import json
from dataclasses import asdict
import pytest

from oil_tracker.adapters.vision.oil_candidate_authority import (
    AuthorityContext, OilCandidateAuthority, evaluate_candidate_authority,
)
from oil_tracker.adapters.vision.oil_candidate_evidence import (
    OilCandidateEvidence, OilCandidateEvidenceIndex, candidate_is_eligible,
)
from oil_tracker.adapters.vision.oil_phase_identity import (
    PhaseIdentityContext, evaluate_phase_identity,
)
from oil_tracker.adapters.vision.oil_observation_resolver import (
    OilObservationResolver, OilObservationResolverConfig, _cross_representation_support,
)
from tests.unit.test_oil_candidate_authority import _candidate
from tests.test_r16_refactor_characterization import _glass, _sequence_detection

INVALID = (float('nan'), float('inf'), -float('inf'), None, 'not-a-number')
MEASUREMENTS = (
    ('features', 'artifact_likelihood'), ('penalties', 'artifact_likelihood'),
    ('features', 'material_texture_conflict'), ('penalties', 'material_texture_conflict'),
    ('penalties', 'optics_conflict'), ('penalties', 'glare_conflict'),
    ('penalties', 'glare_penalty'), ('penalties', 'border_penalty'),
    ('penalties', 'exclusion_conflict'), ('penalties', 'exclusion_penalty'),
    ('features', 'boundary_likelihood'), ('features', 'broad_strength'),
    ('features', 'region_contrast'), ('features', 'narrow_peak_strength'),
    ('features', 'edge_strength'), ('features', 'narrow_horizontal_coverage'),
    ('features', 'horizontal_coverage'), ('features', 'broad_scale_consistency'),
    ('features', 'polarity_confidence'), ('features', 'static_prior_contribution'),
    ('features', 'registered_oil_band_motion_support'),
    ('features', 'registered_oil_band_motion_coverage'),
    ('features', 'sequence_eligible'), ('features', 'evidence_availability'),
    ('features', 'visibility'), ('features', 'calibrated_artifact_match'),
    ('features', 'phase_transition_scan'), ('features', 'r9_calibrated_high_recall'),
    ('candidate', 'y'), ('candidate', 'feature_score'),
    ('candidate', 'penalty'), ('candidate', 'final_score'),
)


@pytest.mark.parametrize('value', INVALID)
@pytest.mark.parametrize(('scope', 'key'), MEASUREMENTS)
def test_invalid_measurement_never_becomes_identity_or_authority(scope, key, value):
    candidate = _candidate()
    if scope == 'candidate':
        setattr(candidate, key, value)
    else:
        getattr(candidate, scope)[key] = value
    before = json.dumps(asdict(candidate), sort_keys=True)
    # Exercise normalization too: malformed optical values must not crash indexing.
    normalized = OilCandidateEvidence.from_candidate(candidate)
    assert not candidate_is_eligible(candidate, normalized)
    decision = evaluate_candidate_authority(candidate, OilObservationResolverConfig(),
        AuthorityContext(), evidence=normalized)
    assert decision.tier is OilCandidateAuthority.HARD_INVALID
    identity = evaluate_phase_identity(candidate, OilObservationResolverConfig(),
        PhaseIdentityContext(), evidence=normalized)
    assert not identity.independently_identified
    assert json.dumps(asdict(candidate), sort_keys=True) == before


@pytest.mark.parametrize('value', INVALID)
def test_invalid_peer_cannot_corroborate_via_cached_evidence(value):
    target = _candidate(material_path=True)
    peer = _candidate()
    index = OilCandidateEvidenceIndex()
    index.register(target)
    index.register(peer)
    assert _cross_representation_support(target, (target, peer), _glass(),
        evidence_index=index) > 0
    peer.features['artifact_likelihood'] = value
    assert _cross_representation_support(target, (target, peer), _glass(),
        evidence_index=index) == 0


@pytest.mark.parametrize('value', INVALID)
def test_repeated_invalid_opposition_does_not_publish_numeric_oil(value):
    candidate = _candidate()
    candidate.penalties['glare_conflict'] = value
    rows = tuple(_sequence_detection(i, deepcopy(candidate)) for i in range(8))
    resolved = OilObservationResolver().resolve(rows, _glass())
    assert all(d.raw_oil_air_level_y is None for d in resolved.detections)
    assert all(not c.selected for d in resolved.detections for c in d.candidates)


def test_omitted_optional_evidence_and_diagnostic_metadata_remain_compatible():
    candidate = _candidate()
    expected = evaluate_candidate_authority(candidate, OilObservationResolverConfig(),
        AuthorityContext())
    candidate.features['sequence_authority_failed_gates'] = 'a;b'
    candidate.features['debug_unavailable_value'] = None
    assert evaluate_candidate_authority(candidate, OilObservationResolverConfig(),
        AuthorityContext()) == expected
    candidate.features.pop('material_texture_conflict')
    candidate.penalties.pop('material_texture_conflict')
    evidence = OilCandidateEvidence.from_candidate(candidate)
    assert not evidence.availability.material_texture
    assert candidate_is_eligible(candidate, evidence)


@pytest.mark.parametrize('left', (-2.0, 0.0, 0.2, 0.7, 1.0, 2.0))
@pytest.mark.parametrize('right', (-2.0, 0.0, 0.2, 0.7, 1.0, 2.0))
def test_finite_optics_normalization_is_unchanged(left, right):
    candidate = _candidate()
    candidate.penalties.update(optics_conflict=left, glare_conflict=right)
    observed = OilCandidateEvidence.from_candidate(candidate).optics_opposition
    assert observed == min(1.0, max(0.0, max(left, right)))


@pytest.mark.parametrize('value', INVALID)
def test_invalid_oil_cannot_continue_foam_material_identity(value):
    from oil_tracker.adapters.vision.foam_material_identity import _can_continue_material_identity
    candidate = _candidate(material_path=True)
    index = OilCandidateEvidenceIndex()
    index.register(candidate)
    assert _can_continue_material_identity(candidate, evidence_index=index)
    candidate.features['artifact_likelihood'] = value
    assert not _can_continue_material_identity(candidate, evidence_index=index)


@pytest.mark.parametrize('value', (float('nan'), float('inf'), None))
def test_invalid_foam_geometry_cannot_seed_oil_material_context(value):
    from oil_tracker.adapters.vision.foam_material_identity import track_foam_material_identity
    from oil_tracker.domain.enums import BoundaryKind
    candidate = _candidate()
    candidate.kind = BoundaryKind.FOAM_FRONT
    candidate.y = value
    candidate.features['sequence_foam_eligible'] = 1.0
    result = track_foam_material_identity((_sequence_detection(0, candidate),), _glass())
    assert result.seeded_frame_count == 0
    assert result.row_by_frame == {}


def test_invalid_field_order_is_independent_of_dictionary_insertion_order():
    from oil_tracker.adapters.vision.oil_candidate_evidence import invalid_candidate_evidence_fields
    candidate = _candidate()
    candidate.y = None
    candidate.features.update(visibility=None, artifact_likelihood=float('nan'))
    candidate.penalties.update(optics_conflict=None, glare_conflict=float('inf'))
    expected = ('y', 'features.artifact_likelihood', 'features.visibility',
                'penalties.glare_conflict', 'penalties.optics_conflict')
    assert invalid_candidate_evidence_fields(candidate) == expected
    candidate.features = dict(reversed(tuple(candidate.features.items())))
    candidate.penalties = dict(reversed(tuple(candidate.penalties.items())))
    assert invalid_candidate_evidence_fields(candidate) == expected


def test_scalar_conversion_overflow_is_hard_invalid_without_raising():
    candidate = _candidate()
    candidate.feature_score = 10**400
    normalized = OilCandidateEvidence.from_candidate(candidate)
    decision = evaluate_candidate_authority(candidate, OilObservationResolverConfig(),
        AuthorityContext(), evidence=normalized)
    assert decision.tier is OilCandidateAuthority.HARD_INVALID
    assert decision.failed_gates == ('finite:feature_score',)
