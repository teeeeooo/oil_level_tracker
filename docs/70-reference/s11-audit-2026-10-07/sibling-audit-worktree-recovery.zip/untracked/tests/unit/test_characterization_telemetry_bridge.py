from __future__ import annotations

from copy import deepcopy
import pytest
from tests.test_r16_refactor_characterization import (
    _pre_phase_reason_diagnostic, _r21_behavioral_view,
)


@pytest.mark.parametrize('reason', (
    '', None, 'boundary_advantage', 'boundary;new_gate;localized_boundary',
    'boundary;boundary_advantage;localized_boundary;new_gate',
))
def test_reason_bridge_does_not_strip_unknown_or_partial_diagnostics(reason):
    assert _pre_phase_reason_diagnostic(reason) == reason


def test_reason_bridge_translates_only_the_exact_documented_correction():
    assert _pre_phase_reason_diagnostic(
        'boundary;boundary_advantage;localized_boundary'
    ) == 'boundary;localized_boundary'


def payload():
    return {'diagnostics': {'version': 'r22'}, 'detections': [{
        'sequence_metrics': {'sequence_selected_authority': 3,
            'sequence_selected_phase_identity': 'direct_interface',
            'sequence_selected_authority_failed_gates':
                'boundary;boundary_advantage;localized_boundary'},
        'candidates': [{'y': 100.0, 'selected': True, 'final_score': .6,
            'features': {'boundary_likelihood': .6, 'artifact_likelihood': .05,
                'sequence_authority': 3,
                'sequence_phase_identity': 'direct_interface',
                'sequence_authority_failed_gates':
                    'boundary;boundary_advantage;localized_boundary'}}]}]}


@pytest.mark.parametrize(('path', 'value'), (
    (('detections', 0, 'candidates', 0, 'y'), 101.0),
    (('detections', 0, 'candidates', 0, 'selected'), False),
    (('detections', 0, 'candidates', 0, 'final_score'), .9),
    (('detections', 0, 'candidates', 0, 'features', 'boundary_likelihood'), .8),
    (('detections', 0, 'candidates', 0, 'features', 'artifact_likelihood'), .9),
    (('detections', 0, 'candidates', 0, 'features', 'sequence_authority'), 1),
    (('detections', 0, 'candidates', 0, 'features', 'sequence_phase_identity'), 'opposed_material'),
    (('detections', 0, 'sequence_metrics', 'sequence_selected_authority'), 1),
    (('detections', 0, 'sequence_metrics', 'sequence_selected_phase_identity'), 'opposed_material'),
    (('detections', 0, 'sequence_metrics', 'unexpected_diagnostic'), 'new'),
))
def test_behavioral_mutation_survives_diagnostic_bridge(path, value):
    original = payload()
    changed = deepcopy(original)
    target = changed
    for key in path[:-1]:
        target = target[key]
    target[path[-1]] = value
    assert _r21_behavioral_view(changed) != _r21_behavioral_view(original)
    assert original == payload()
