from __future__ import annotations
from copy import deepcopy
import pytest
from oil_tracker.application.services.graph_series import observed_trajectory
from oil_tracker.application.services.report_presentation import build_glass_report_presentation
from oil_tracker.domain.enums import FillState, ResultState, EventType
from oil_tracker.domain.recipe import InspectionRecipe
from oil_tracker.domain.results import TrackingSample, GlassAnalysisResult


def make_sample(gid, time, oil, *, foam=None, flags=()):
    return TrackingSample('run',gid,int(time*30),time,
        FillState.PARTIAL_VISIBLE if oil is not None else FillState.UNKNOWN_REVIEW,
        raw_oil_air_level_y=None if oil is None else 100-oil,
        raw_oil_air_level_px_from_zero=oil, smoothed_oil_air_level_px_from_zero=oil,
        raw_foam_front_px_from_zero=foam, smoothed_foam_front_px_from_zero=foam,
        is_valid=oil is not None, oil_is_valid=oil is not None,
        foam_is_valid=foam is not None, flags=list(flags))


def report_for(values, *, flags=()):
    config=InspectionRecipe.default_glass(320,240,1)
    glass=GlassAnalysisResult(config.id,config.name,ResultState.REVIEW_REQUIRED,
        samples=[make_sample(config.id,i*.5,v,flags=flags) for i,v in enumerate(values)])
    before=deepcopy(glass)
    report=build_glass_report_presentation(glass,config)
    assert glass == before
    return report,glass


@pytest.mark.parametrize('foam_flag',['R7_FOAM_UNCONFIRMED','R7_FOAM_REJECTED','R7_FOAM_OIL_TOPOLOGY_CONFLICT'])
def test_foam_namespace_does_not_select_legacy_oil_extrema_regime(foam_flag):
    report,_=report_for([1,9,3],flags=('R17_RESOLVED_OIL','SEQUENCE_SAME_FRAME_CANDIDATE',foam_flag))
    extrema={x.event_type:x.oil_level_px for x in report.landmarks}
    assert extrema[EventType.MAXIMUM_OIL_LEVEL] == 9
    assert extrema[EventType.MINIMUM_OIL_LEVEL] == 1


def test_legacy_r7_continuation_still_cannot_be_extremum():
    config=InspectionRecipe.default_glass(320,240,1)
    samples=[make_sample(config.id,0,1,flags=('R7_RESOLVED_OIL','R7_OIL_ANCHOR')),
        make_sample(config.id,.5,999,flags=('R7_RESOLVED_OIL','R7_OIL_CONTINUATION')),
        make_sample(config.id,1,9,flags=('R7_RESOLVED_OIL','R7_OIL_ANCHOR'))]
    glass=GlassAnalysisResult(config.id,config.name,ResultState.REVIEW_REQUIRED,samples=samples)
    report=build_glass_report_presentation(glass,config)
    maximum=next(x for x in report.landmarks if x.event_type is EventType.MAXIMUM_OIL_LEVEL)
    assert maximum.sample is samples[-1]


@pytest.mark.parametrize('values',[[0,-5,-10,-5,0],[0,5,10,5,0],list(range(0,-22,-2))+list(range(-18,2,2))])
def test_equal_endpoints_are_not_reported_as_entire_window_steady(values):
    report,_=report_for(values)
    assert '유지되었습니다' not in report.movement_summary
    assert '전 구간이 정체했다는 뜻은 아닙니다' in report.movement_summary


@pytest.mark.parametrize('values',[[],[None,None],[0],[5,5,5]])
def test_missing_singleton_and_flat_inputs_preserve_samples(values):
    report,glass=report_for(values)
    assert report.finite_oil_count == sum(v is not None for v in values)
    assert len(glass.samples) == len(values)
    if values == [0]: assert '단일 관측' in report.movement_summary


def test_foam_unknown_does_not_claim_physical_disappearance():
    config=InspectionRecipe.default_glass(320,240,1)
    samples=[make_sample(config.id,0,None,foam=5),make_sample(config.id,.5,None,foam=6),make_sample(config.id,1,None)]
    glass=GlassAnalysisResult(config.id,config.name,ResultState.REVIEW_REQUIRED,samples=samples)
    before=deepcopy(glass);report=build_glass_report_presentation(glass,config)
    end=next(x for x in report.landmarks if x.event_type is EventType.FOAM_END)
    assert '관측 중단' in end.label
    assert '확정하지 않습니다' in end.description
    assert end.timestamp_sec == 1
    assert glass == before


@pytest.mark.parametrize('cap',[0,1,2,5,None])
def test_gap_policy_never_adds_or_changes_anchors(cap):
    times=(0.,.5,1.,10.,10.5);values=(1.,None,2.,None,3.)
    trajectory=observed_trajectory(times,values,max_gap_sec=cap)
    assert trajectory.anchors == ((0.,1.),(1.,2.),(10.5,3.))
    if cap is not None: assert all(b.timestamps[-1]-b.timestamps[0]<=cap for b in trajectory.gap_bridges)
