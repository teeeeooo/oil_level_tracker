# S11 Report Context Presentation Design

This bounded proposal refines the existing [report architecture](result-observation-report-architecture.md), not its ownership. The [work plan](../00-project/work-plan.md) remains the current-state owner. It changes only static-report explanation of stored results; interactive Result Review and domain-event extraction remain separate consumers.

Base: `a48124c9e9479864c988f6054935d48f8cc4897d`.
Disposition: isolated, unadopted report-only experiment. Main is unchanged.
The current user prioritizes graph movement context over perfect detection.
The existing product SSOT section 1.2 already states this objective.

## Mechanisms and limits

- An unrelated `R7_FOAM_*` flag must not select legacy R7 Oil-extrema eligibility.
  Exact legacy Oil flags still retain the historical anchor-only protection.
- A provisional two-second display gap cap preserves every existing anchor.
  Longer gaps are left open; no sample, coordinate or event is synthesized.
  This is a presentation policy candidate, not a calibrated physical timescale.
- Similar first and last observations do not imply a steady full interval.
- A lost Foam-front observation does not establish physical Foam disappearance.

Runtime detector, thresholds, candidates, scalar truth, recipes, CSV semantics,
judgment and field disposition are not changed by this patch. Review UI still
uses its existing presentation path and is not claimed equal to this prototype.
Fresh fixed-window report replays and focused/canonical tests are recorded in
`sample/output/s11-third-audit-context-20261007-001` of the main checkout.
The separate human-ROI replay changes an input only and is not this code patch.

## Detector Governance

- Logic-map nodes: `RESULT-PRESENTATION`, `PUBLICATION-PROVENANCE`, `CSV-PUBLICATION`.
- Failure-registry entries: `S11-F09`, `S11-F10`.
- First harmful stage: `RESULT-PRESENTATION`; namespace-based Oil-extrema suppression and unbounded display gaps. Upstream physical identity is not repaired.

- Logic-map impact: NONE — existing presentation owners remain; no detector flow, authority or publication data owner is added.
- Failure-registry impact: NONE — the existing provenance/display guard is exercised; no failure class is retired.

## History Review

- Logic-map nodes: `RESULT-PRESENTATION`, `PUBLICATION-PROVENANCE`, `CSV-PUBLICATION`.
- Failure-registry entries: `S11-F09`, `S11-F10`.
- Prior mechanisms reviewed: R1 observed-run versus display-bridge distinction, R7 anchor-only extrema, current Oil/Foam independent validity, both supplied 2026-10-07 audits.
- Prior mechanisms rejected: interpolation/carry as numeric observations, global detector threshold relaxation, Foam-to-Oil authority, declaring missing Foam a physical end.
- Preserved contracts: unchanged numeric anchors, same-frame provenance, independent series, immutable original input and historical fingerprints, separate field qualification.
- Difference from prior failures: change only the explanation of stored observations; preserve short display bridges but bound elapsed-time inference, and remove unrelated Foam namespace influence on report-only Oil landmarks.
- Logic-map impact: NONE — no new runtime owner or detector branch.
- Failure-registry impact: NONE — a bounded presentation repair, not detector or field promotion.
