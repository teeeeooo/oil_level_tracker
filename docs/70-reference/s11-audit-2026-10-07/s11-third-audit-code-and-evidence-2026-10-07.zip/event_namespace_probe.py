from __future__ import annotations
import argparse, copy, csv, json
from pathlib import Path
from dataclasses import asdict, fields
from oil_tracker.domain import events
from oil_tracker.domain.results import TrackingSample
from oil_tracker.domain.enums import FillState

LEGACY_OIL_FLAGS = frozenset({'R7_RESOLVED_OIL','R7_OIL_ANCHOR','R7_OIL_CONTINUATION'})
def oil_scoped_r7(sample):
    return bool({str(flag).strip().upper() for flag in sample.flags} & LEGACY_OIL_FLAGS)

def load_samples(path):
    result=[]
    with path.open(encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f):
            kw={}
            for field in fields(TrackingSample):
                name=field.name;value=row.get(name,'')
                if name in ('run_id','glass_id'): kw[name]=value
                elif name=='frame_index':kw[name]=int(value)
                elif name=='fill_state':kw[name]=FillState(value)
                elif name=='flags':kw[name]=value.split(';') if value else []
                elif name in ('is_valid','oil_is_valid','foam_is_valid'):kw[name]=None if value=='' else value=='True'
                else:kw[name]=None if value=='' else float(value)
            result.append(TrackingSample(**kw))
    return result

def event_keys(output):
    return {(e.event_type.value,e.start_time_sec,e.end_time_sec,e.representative_frame_index) for e in output}


def compare_case(csv_path):
    samples=load_samples(csv_path)
    before=copy.deepcopy(samples)
    original=events._is_r7_sample
    baseline=events.detect_events_for_glass(samples[0].run_id,samples[0].glass_id,samples)
    try:
        events._is_r7_sample=oil_scoped_r7
        candidate=events.detect_events_for_glass(samples[0].run_id,samples[0].glass_id,samples)
    finally:
        events._is_r7_sample=original
    assert samples==before
    bk=event_keys(baseline);ck=event_keys(candidate)
    assert {x for x in bk if x[0].startswith('FOAM_')}=={x for x in ck if x[0].startswith('FOAM_')}
    return {'rows':len(samples),'added':sorted(ck-bk),'removed':sorted(bk-ck),
        'samples_unchanged':True,'foam_events_unchanged':True}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input-root',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    if args.output.exists():raise FileExistsError(args.output)
    results={p.parent.parent.name:compare_case(p) for p in args.input_root.glob('*/*/tracking_data.csv')}
    args.output.write_text(json.dumps(results,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
