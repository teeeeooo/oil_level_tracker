# S11 third audit: report-context prototype

Base: `a48124c9e9479864c988f6054935d48f8cc4897d`.
This packet contains a reviewable, unadopted **report-only** patch, actual test/probe code and selected evidence. No detector source, original recipe/truth, main commit, push, merge or field promotion is included.

- `report-context.patch`: three reporting source files, 17-case test, S11 design proposal and catalog entry. Review before `git apply --check` / `git apply` on the matching base.
- `run_context_replay.py`: fresh official application/report replay. Supply `--root` for existing sample inputs, `--source` for exact source tree, `--output` for a NEW directory, `--sample` and `--mode`. Mode labels do not change which source is imported.
- `collect_context.py`: saved second-audit CSV analysis and 40 source-frame crops. Always supply a NEW output directory; this analysis helper is not a production no-overwrite exporter.
- `event_namespace_probe.py`: isolated domain-event predicate probe over saved output. It is NOT included in the report patch and is NOT a validated event-release patch.
- `delivery-summary.json`, `validation-summary.json`, `preservation-receipt.json`: selected facts and integrity. These are not byte copies of every native execution artifact.
- `prototype-plan.json`, `event-probe-plan.json`: fixed experiment scopes before execution.
- `report-focused.xml`: actual 36-test focused result; the 17 new cases are included, not additive.

Full Mac evidence: `/Users/sunjaekim/Developer/oil_level_tracker/sample/output/s11-third-audit-context-20261007-001`.
It contains 9 application/report bundles, raw source crops, canonical JUnit/logs and corpus-mount recovery receipts. These large assets, original videos, fonts and private Windows material are NOT included here.

The two-second graph cap is a provisional display policy, not a detector threshold or calibrated physical timescale. All stored observations remain unchanged in the report-only four-video comparison. Increased Foam output from human ROI is not claimed to be correct detection.

`manifest.json` hashes each payload other than the manifest itself. Re-execution requires the repository, its compatible Python environment, original sample pins and (only for human-ROI mode) the previously reviewed human ROI file.
