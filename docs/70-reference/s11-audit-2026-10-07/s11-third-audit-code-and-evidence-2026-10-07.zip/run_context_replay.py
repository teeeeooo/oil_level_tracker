from __future__ import annotations
import argparse, copy, hashlib, json, sys, time
from dataclasses import asdict, replace
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    for name in ('root','source','output'): ap.add_argument('--'+name,type=Path,required=True)
    ap.add_argument('--sample',required=True)
    ap.add_argument('--mode',choices=('baseline','prototype','human-roi'),required=True)
    args=ap.parse_args();root=args.root;out=args.output
    if out.exists(): raise FileExistsError(out)
    out.mkdir(parents=True)
    sys.path[:0]=[str(args.source/'src'),str(args.source),str(args.source/'tests')]
    from tests.diagnostics import s11_report_observability_replay as replay
    from tests.diagnostics.s11_observation_replay_audit import tracking_rows, sequence_audit, user_truth_audit
    from oil_tracker.adapters.storage.json_recipe_repository import JsonRecipeRepository
    from oil_tracker.adapters.storage.output_bundle_store import OutputBundleStore
    from oil_tracker.adapters.vision.opencv_phase_detector import OpenCvPhaseDetector
    from oil_tracker.adapters.vision.opencv_video_reader import OpenCvVideoReader
    from oil_tracker.application.services.analysis_pipeline import AnalysisPipeline
    from oil_tracker.application.services.recipe_validation_service import RecipeValidationService
    from oil_tracker.application.services.report_presentation import build_report_presentation
    from oil_tracker.application.services.graph_series import observed_trajectory
    start,end=replay.QUALIFICATION_WINDOWS[args.sample]
    recipe,session=replay._session(args.sample,root/'sample'/f'{args.sample}.mp4',out,start,end,
        run_label=f'S11 context {args.mode}',run_note='Exposed corpus; report-context audit, not field qualification')
    original_recipe=recipe.to_dict()

    roi_pin=None
    if args.mode=='human-roi':
        if args.sample!='sample4':raise ValueError('Only the previously human-reviewed sample4 ROI is available')
        rp=root/'sample/output/s11-local-human-roi-comparison-001/sample4-human-roi.oilrecipe'
        hr=JsonRecipeRepository().load(rp)
        recipe.glasses[0].geometry=replace(recipe.glasses[0].geometry,ellipse=copy.deepcopy(hr.glasses[0].geometry.ellipse))
        roi_pin=hashlib.sha256(rp.read_bytes()).hexdigest()
    started=time.monotonic()
    result=AnalysisPipeline(lambda path:OpenCvVideoReader(path),OpenCvPhaseDetector(),RecipeValidationService()).run(recipe,session)
    pre=replay._tracking_fingerprint(result)
    events_before=[(e.glass_id,e.event_type.value,e.start_time_sec,e.end_time_sec,e.representative_frame_index) for g in result.glass_results for e in g.events]
    bundle=OutputBundleStore().write_bundle(result,recipe,session,out)
    assert pre==replay._tracking_fingerprint(result)
    report=build_report_presentation(result,recipe)
    rows=tracking_rows(bundle);provenance=sequence_audit(rows)
    assert provenance['numeric_without_same_frame_provenance']==0
    summary=replay._sample_summary(args.sample,result,recipe,bundle)
    summary.update(mode=args.mode,source_root=str(args.source),runtime_seconds=time.monotonic()-started,
        provenance=provenance,truth=user_truth_audit(root,args.sample,rows),human_roi_pin=roi_pin,
        original_recipe=original_recipe,executed_recipe=recipe.to_dict(),events=events_before,
        reports=[dict(glass_id=g.glass_id,movement=g.movement_summary,note=g.observation_note,
            extrema_count=sum(x.event_type.value in ('MAXIMUM_OIL_LEVEL','MINIMUM_OIL_LEVEL') for x in g.landmarks),
            landmarks=[dict(type=x.event_type.value,time=x.timestamp_sec,label=x.label,description=x.description) for x in g.landmarks]) for g in report.glasses])
    summary['series']=[dict(frame=s.frame_index,t=s.timestamp_sec,oil_y=s.raw_oil_air_level_y,
        oil_h=s.smoothed_oil_air_level_px_from_zero,foam_y=s.raw_foam_front_y,
        foam_h=s.smoothed_foam_front_px_from_zero,oil_valid=s.oil_is_valid,foam_valid=s.foam_is_valid,
        state=s.fill_state.value,flags=s.flags) for g in result.glass_results for s in g.samples]
    (out/'result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(args.mode,args.sample,'rows',len(rows),'oil',summary['numeric_oil_count'],'extrema',summary['reports'][0]['extrema_count'],'sha',pre,flush=True)
if __name__=='__main__':main()
