from __future__ import annotations
import argparse,csv,hashlib,json
from pathlib import Path

def load_csv(path,ignore):
    with path.open(encoding='utf-8-sig',newline='') as f:
        return [{k:v for k,v in r.items() if k not in ignore} for r in csv.DictReader(f)]

def leaf_diff(a,b,prefix=''):
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for key in sorted(a.keys()|b.keys()):out.extend(leaf_diff(a.get(key),b.get(key),prefix+'/'+key))
        return out
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [x for i,(aa,bb) in enumerate(zip(a,b)) for x in leaf_diff(aa,bb,prefix+'/'+str(i))]
    return [] if a==b else [{'path':prefix,'before':a,'after':b}]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--evidence',type=Path,required=True)
    a=ap.parse_args().evidence
    runs={(p.parent.parent.name,p.parent.name):json.loads(p.read_text()) for p in (a/'replays').glob('*/*/result.json')}
    metrics=json.loads((a/'visual-audit/context-metrics.json').read_text())
    summary={'kind':'selected-delivery-summary-not-full-execution-evidence','base_head':(a/'base-head.txt').read_text().strip(),
        'report_source_files':3,'new_test_cases':17,'comparisons':{},'prior_pair_context':{},
        'fresh_application_runs':9,'fresh_application_rows':711,'source_frames_reviewed':40}

    for name in ('base_sample_1','sample2','sample3','sample4'):
        b=runs['baseline',name];p=runs['prototype',name]
        assert b['series']==p['series'] and b['truth']==p['truth'] and b['events']==p['events']
        bc=Path(b['bundle']);pc=Path(p['bundle'])
        assert load_csv(bc/'tracking_data.csv',{'run_id'})==load_csv(pc/'tracking_data.csv',{'run_id'})
        assert load_csv(bc/'events.csv',{'run_id','capture_path'})==load_csv(pc/'events.csv',{'run_id','capture_path'})
        oil=metrics['cases'][name]['baseline']['oil']
        summary['comparisons'][name]={'rows':len(b['series']),'oil':b['numeric_oil_count'],
            'foam':sum(s['foam_y'] is not None for s in b['series']),'all_tracking_columns_equal_except_run_id':True,
            'events_semantics_equal':True,'truth_equal':True,'fingerprint':b['tracking_fingerprint_sha256'],
            'extrema_before_after':[b['reports'][0]['extrema_count'],p['reports'][0]['extrema_count']],
            'captures_before_after':[b['capture_count'],p['capture_count']],
            'longest_internal_gap_sec':oil['longest_internal_anchor_gap_sec'],
            'removed_long_bridges':[x for x in oil['brackets'] if x['span_sec']>2],
            'baseline_report':b['reports'][0],'prototype_report':p['reports'][0]}
        summary['prior_pair_context'][name]={m:dict(oil=v['oil']['numeric'],foam=v['foam']['numeric'],
            longest_internal_gap_sec=v['oil']['longest_internal_anchor_gap_sec']) for m,v in metrics['cases'][name].items()}
    h=runs['human-roi','sample4'];o=runs['baseline','sample4']
    differences=leaf_diff(h['original_recipe'],h['executed_recipe'])
    assert differences and all('/geometry/ellipse/' in d['path'] for d in differences)
    summary['human_roi']={'sample':'sample4','rows':len(h['series']),'oil':h['numeric_oil_count'],
        'foam':sum(s['foam_y'] is not None for s in h['series']),'recipe_changes':differences,
        'recipe_sha256':h['human_roi_pin'],'tracking_fingerprint':h['tracking_fingerprint_sha256'],
        'truth_original':o['truth'],'truth_human_roi':h['truth'],'report':h['reports'][0],
        'last_oil_time':max(s['t'] for s in h['series'] if s['oil_y'] is not None)}

    summary['event_probe']=json.loads((a/'event-namespace-result.json').read_text())
    summary['input_pins']=metrics['pins']
    summary['full_evidence_root']=str(a)
    (a/'delivery-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print('4 report comparisons: all stored CSV tracking columns equal except run_id; truth and event semantics equal.')
    print('Human ROI changed only ellipse leaves:',differences)
if __name__=='__main__':main()
