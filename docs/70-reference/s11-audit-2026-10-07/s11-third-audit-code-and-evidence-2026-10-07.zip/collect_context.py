from __future__ import annotations
import argparse, csv, hashlib, json, math
from pathlib import Path
from dataclasses import asdict
import cv2
import numpy as np
from oil_tracker.adapters.storage.json_recipe_repository import JsonRecipeRepository
from oil_tracker.application.services.graph_series import observed_trajectory

TIMES = {
    'base_sample_1': [0, 1, 2, 4, 6, 8, 11, 14],
    'sample2': [0, .3, .6, .9, 1.2, 1.5, 1.8, 2],
    'sample3': [30.03, 32, 34, 40, 50, 60, 70, 81, 88, 92, 100, 105],
    'sample4': [0, 8, 14, 20, 30, 38, 40, 44, 48, 52, 54, 56],
}
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''): h.update(chunk)
    return h.hexdigest()
def analyze(rows, field):
    times = [float(r['timestamp_sec']) for r in rows]
    values = [float(r[field]) if r[field] else None for r in rows]
    tr = observed_trajectory(times, values)
    brackets = [dict(start=b.timestamps[0], end=b.timestamps[1],
                     span_sec=b.timestamps[1]-b.timestamps[0]) for b in tr.gap_bridges]
    numeric = [(t,v) for t,v in zip(times,values) if v is not None]
    return {'rows': len(rows), 'numeric': len(numeric), 'runs': len(tr.observed_runs),
        'singletons': sum(len(r.timestamps)==1 for r in tr.observed_runs),        'brackets': brackets, 'longest_internal_anchor_gap_sec': max((b['span_sec'] for b in brackets),default=0),
        'leading_unobserved_to_first_anchor_sec': numeric[0][0]-times[0] if numeric else None,
        'trailing_last_anchor_to_end_sec': times[-1]-numeric[-1][0] if numeric else None,
        'first': numeric[0] if numeric else None, 'last': numeric[-1] if numeric else None,
        'minimum_y': min(numeric,key=lambda x:x[1]) if numeric else None,
        'maximum_y': max(numeric,key=lambda x:x[1]) if numeric else None,
        'numeric_with_invalid_series': sum(bool(r[field]) and r['oil_is_valid' if 'oil' in field else 'foam_is_valid']!='True' for r in rows)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args();root=args.root;out=args.output;out.mkdir(parents=True,exist_ok=True)
    old=root/'sample/output/s11-second-audit-20261007-001'
    summary={'kind':'descriptive-report-context-audit-not-accuracy','cases':{},'pins':{},'frames':[]}
    for name in TIMES:
        summary['cases'][name]={}
        for mode in ['baseline','challenger']:
            p=next((old/f'paired-public-{mode}'/name).glob('*/tracking_data.csv'))
            with p.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
            summary['cases'][name][mode]={k:analyze(rows,field) for k,field in [('oil','raw_oil_air_level_y'),('foam','raw_foam_front_y')]}
            summary['cases'][name][mode]['csv_sha256']=digest(p)
            flags=[r for r in rows if r['raw_oil_air_level_y']]
            summary['cases'][name][mode]['numeric_rows_any_r7_flag']=sum(any(f.startswith('R7_') for f in r['flags'].split(';')) for r in flags)
            summary['cases'][name][mode]['numeric_rows_r7_oil_anchor']=sum('R7_OIL_ANCHOR' in r['flags'].split(';') for r in flags)
        for ext in ['mp4','oilrecipe','oiltruth']:
            p=root/'sample'/f'{name}.{ext}';summary['pins'][str(p)]=digest(p)
        config=JsonRecipeRepository().load(root/'sample'/f'{name}.oilrecipe').glasses[0]
        e=config.geometry.ellipse
        cap=cv2.VideoCapture(str(root/'sample'/f'{name}.mp4'));fps=cap.get(cv2.CAP_PROP_FPS)
        if not cap.isOpened():raise RuntimeError(name)
        tiles=[]
        for time_sec in TIMES[name]:
            index=round(time_sec*fps);cap.set(cv2.CAP_PROP_POS_FRAMES,index);ok,frame=cap.read()
            if not ok:raise RuntimeError((name,index))
            actual=int(cap.get(cv2.CAP_PROP_POS_FRAMES))-1
            x0=max(0,int(e.center_x-e.radius_x));x1=min(frame.shape[1],int(e.center_x+e.radius_x)+1)
            y0=max(0,int(e.center_y-e.radius_y));y1=min(frame.shape[0],int(e.center_y+e.radius_y)+1)
            crop=frame[y0:y1,x0:x1];fn=f'{name}-f{actual}-source-crop.png'
            assert cv2.imwrite(str(out/fn),crop)
            tile=np.zeros((336,300,3),dtype=np.uint8)
            scaled=cv2.resize(crop,(300,300),interpolation=cv2.INTER_NEAREST)
            tile[36:]=scaled;cv2.putText(tile,f'{actual/fps:.3f}s  f{actual}',(8,24),cv2.FONT_HERSHEY_SIMPLEX,.6,(255,255,255),1)
            tiles.append(tile)
            summary['frames'].append(dict(sample=name,requested_sec=time_sec,frame_index=actual,decoded_next_index=actual+1,
                timestamp_sec=cap.get(cv2.CAP_PROP_POS_MSEC)/1000,fps=fps,crop=[x0,y0,x1,y1],file=fn,sha256=digest(out/fn)))
        cap.release()
        sheet=np.concatenate([np.concatenate(tiles[i:i+4],axis=1) for i in range(0,len(tiles),4)],axis=0)
        assert cv2.imwrite(str(out/f'{name}-contact-sheet.png'),sheet)
    (out/'context-metrics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps(summary['cases'],ensure_ascii=False,indent=2))
if __name__=='__main__':main()
